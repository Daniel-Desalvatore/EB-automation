from health_check_ping import ping_server
from database import DatabaseConnector
import mysql.connector

class health_check():
    """
    A class to perform health checks on various servers.
    
    This class is responsible for checking the health of Non-Production, Production,
    FOIL, and external application servers by pinging them and storing their status.
    
    Attributes:
        db (DatabaseConnector): An instance of DatabaseConnector to interact with the database.
        ping (ping_server): An instance of ping_server to perform the actual pinging of servers.
        server_status (list): A list to store the status of each server after a health check.
    """
    
    def __init__(self) -> None:
        """
        The constructor for health_check class.
        
        Initializes the database connector, ping server, and server status list.
        """
        self.db = DatabaseConnector()  # Initialize the database connector
        self.ping = ping_server()      # Initialize the ping server
        self.server_status = []        # Initialize the list to store server status
        
    def check_NonProd_servers(self):
        """
        Checks the health of Non-Production servers and updates their status.
        
        This method queries the database for enabled Non-Production servers, categorizes them
        based on whether they require credentials for access, and then pings each server to
        check its health. The results are appended to the server_status list.
        """
        no_cred_urls = []  # List to store URLs of servers that don't require credentials
        cred_urls = []     # List to store URLs and credentials of servers that require credentials
        
        # Establish a connection to the database
        conn = mysql.connector.connect(
            host=self.db.host,
            user=self.db.user,
            password=self.db.password,
            database=self.db.database
        )
        
        cursor = conn.cursor()
        
        # Query for Non-Production servers that are enabled and do not require credentials
        cursor.execute("""SELECT * FROM healthcheck.nonprod_healthcheck WHERE isEnable = 1 AND cred = 0""")
        rows = cursor.fetchall()
        for row in rows:
            no_cred_urls.append(row[0])  # Append the URL to the no_cred_urls list

        # Query for Non-Production servers that are enabled and require credentials
        cursor.execute("""SELECT * FROM healthcheck.nonprod_healthcheck WHERE isEnable = 1 AND cred = 1""")
        rows = cursor.fetchall()
        for row in rows:
            cred_urls.append([row[0], row[1], row[2]])  # Append the URL and credentials to the cred_urls list
        
        # Ping each server that requires credentials and update the server_status list
        for url in cred_urls:
            ping = self.ping.ping_cred_url(url[0], url[1], url[2], "Non_PROD")
            self.server_status.append(ping)

        # Ping each server that does not require credentials and update the server_status list
        for url in no_cred_urls:
            ping = self.ping.ping_Non_cred_url(url, "Non_PROD")
            self.server_status.append(ping)
        
        # Close the database connection if it's open
        if conn:
            conn.close()
        
    # The following methods follow a similar pattern to check_NonProd_servers:
    # - check_Prod_servers: Checks the health of Production servers.
    # - check_FOIL_servers: Checks the health of FOIL servers.
    # - check_external_apps_servers: Checks the health of external application servers.
    # Each method queries the database for the respective server type, categorizes them,
    # pings them, and updates the server_status list with the results.
    
    # The get_servers_status method resets the server_status list and performs health checks
    # on all server types by calling the respective check methods.
    
    # The get_prod_servers method resets the server_status list and performs health checks
    # on Production, FOIL, and external application servers.
    
    # The get_non_prod_servers method resets the server_status list and performs health checks
    # on Non-Production servers only.
    
    # Note: The code for the remaining methods has been omitted for brevity as they follow
    # the same logic and structure as check_NonProd_servers. They should be documented in a
    # similar manner, explaining the specific server types they handle and any unique logic.
