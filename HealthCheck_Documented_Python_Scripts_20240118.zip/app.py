from flask import Flask, render_template, request, redirect, url_for
from health_check_app import run_health_check  # Assuming a typo in the original import, corrected to 'health_check_app'
from read_current_status import read_status_from_db
import threading
import time
import datetime

# Initialize the Flask application
app = Flask(__name__)

def check_prod():
    """
    Periodically runs health checks on production servers.

    This function creates an instance of the health check class and enters an infinite loop,
    where it calls the run method with the "Prod" environment every 15 minutes.
    """
    HC = run_health_check()  # Create an instance of the health check class
    while True:
        print('checking prod')
        HC.run("Prod")  # Run the health check for production servers
        print(f"done checking Prod will check again at")
        time.sleep(15*60)  # Wait for 15 minutes before the next check

def check_non_prod():
    """
    Periodically runs health checks on non-production servers.

    Similar to check_prod, but for non-production servers and runs every 30 minutes.
    """
    HC = run_health_check()  # Create an instance of the health check class
    while True:
        print('checking non prod')
        HC.run("non_prod")  # Run the health check for non-production servers
        print("done checking Non prod")
        time.sleep(30*60)  # Wait for 30 minutes before the next check

# Define the route for the index page
@app.route('/')
def index():
    """
    Renders the index page with the current status of all servers.

    Retrieves the current status of stable, non-stable, and disabled servers from the database,
    calculates the total number of servers, and passes this information to the 'index.html' template.
    """
    get_current_status = read_status_from_db()  # Create an instance to read the current status from the database
    stable_servers = get_current_status.read_stable_servers()  # Get the list of stable servers
    non_stable_servers = get_current_status.read_non_stable_servers()  # Get the list of non-stable servers
    disabled_servers = get_current_status.read_disabled_servers()  # Get the list of disabled servers
    total_servers = len(stable_servers) + len(non_stable_servers) + len(disabled_servers)  # Calculate the total number of servers
    # Render the index page with the server information
    return render_template('index.html', stable_len=len(stable_servers), non_stable_len=len(non_stable_servers),
                           disabled_servers_len=len(disabled_servers), total_servers=total_servers,
                           stable_servers=stable_servers, non_stable_servers=non_stable_servers,
                           disabled_servers=disabled_servers)

# Define the route for the stable servers page
@app.route('/stable')
def stable():
    """
    Renders the page with the list of stable servers.

    Retrieves the list of stable servers from the database and passes it to the 'stable.html' template.
    """
    get_current_status = read_status_from_db()  # Create an instance to read the current status from the database
    stable_servers = get_current_status.read_stable_servers()  # Get the list of stable servers
    return render_template('stable.html', stable_servers=stable_servers)  # Render the stable servers page

# Define the route for the non-stable servers page
@app.route('/non_stable')
def non_stable():
    """
    Renders the page with the list of non-stable servers.

    Retrieves the list of non-stable servers from the database and passes it to the 'non_stable.html' template.
    """
    get_current_status = read_status_from_db()  # Create an instance to read the current status from the database
    non_stable_servers = get_current_status.read_non_stable_servers()  # Get the list of non-stable servers
    return render_template('non_stable.html', non_stable_servers=non_stable_servers)  # Render the non-stable servers page

# Define the route for the disabled servers page
@app.route('/disabled')
def disabled():
    """
    Renders the page with the list of disabled servers.

    Retrieves the list of disabled servers from the database and passes it to the 'disabled_servers.html' template.
    """
    get_current_status = read_status_from_db()  # Create an instance to read the current status from the database
    disabled_servers = get_current_status.read_disabled_servers()  # Get the list of disabled servers
    return render_template('disabled_servers.html', disabled_servers=disabled_servers)  # Render the disabled servers page

# Define the route to toggle the status of a server
@app.route('/toggle-server', methods=['POST'])
def toggle_server():
    """
    Toggles the status of a server between enabled and disabled.

    Retrieves the requested status, server ID, and environment from the form data,
    reads the current status of the server from the database, updates the server status,
    and redirects to the last page or the index page.
    """
    db = read_status_from_db()  # Create an instance to interact with the database
    requested_status = str(request.form.get('status'))  # Get the requested status from the form data
    server_id = str(request.form.get('server'))  # Get the server ID from the form data
    env = str(request.form.get('env'))  # Get the environment from the form data
    current_db_status = db.read_enabled(server_id, env)  # Read the current status of the server from the database
    db.update_server_isEnable(server_id, env, current_db_status, requested_status)  # Update the server status in the database
    last_page = request.form.get('referrer')  # Get the referrer page from the form data
    if last_page:
        return redirect(last_page)  # Redirect to the last page
    else:
        return redirect('/')  # Redirect to the index page if no referrer is provided

# Define the route to search for a server
@app.route('/search_server', methods=['POST'])
def search_server():
    """
    Searches for a server by name and redirects to the search results page.

    Retrieves the server name from the form data, searches the database for the server,
    checks the recent status of the server, and redirects to the 'server_search_results' route
    with the search results and recent status as query parameters.
    """
    db = read_status_from_db()  # Create an instance to interact with the database
    search_server_name = str(request.form.get('search-bar-server'))  # Get the server name from the form data
    search_data = db.search_db_for_server(search_server_name)  # Search the database for the server
    recent_status = db.check_recent_status(search_server_name)  # Check the recent status of the server
    # Redirect to the search results page with the search data and recent status
    if search_data and recent_status is not None:
        return redirect(url_for('server_search_results', search_results=[search_data[0][0][0], search_data[0][0][3], search_data[0][0][5], search_data[0][0][6], search_data[0][0][7], search_data[0][0][8], search_data[0][0][9], search_data[0][0][10], search_data[1]],
                                recent_status=[recent_status[0][0], recent_status[0][1], recent_status[0][2], recent_status[0][3], recent_status[0][4], recent_status[0][5], recent_status[0][6], recent_status[0][7]]))
    elif search_data:
        if not recent_status:
            # If there is no recent status, use "NA" placeholders
            return redirect(url_for('server_search_results', search_results=[search_data[0][0][0], search_data[0][0][3], search_data[0][0][5], search_data[0][0][6], search_data[0][0][7], search_data[0][0][8], search_data[0][0][9], search_data[0][0][10], search_data[1]],
                                    recent_status=["NA", "NA", "NA", "NA", "NA", "NA", "NA"]))
    else:
        return redirect('/')  # Redirect to the index page if no search data is found

# Define the route for displaying search results for a server
@app.route('/server_search_results')
def server_search_results():
    """
    Renders the page with the search results for a server.

    Retrieves the search results and recent status from the query parameters and passes them
    to the 'searched_server.html' template.
    """
    server_data = request.args.getlist('search_results')  # Get the search results from the query parameters
    current_status = request.args.getlist('recent_status')  # Get the recent status from the query parameters
    return render_template('searched_server.html', server_data=server_data, server_env=server_data[1], current_status=current_status)  # Render the search results page

# The main entry point of the Flask application
if __name__ == '__main__':
    # Uncomment the following lines to enable periodic health checks using threading
    # prod_check = threading.Thread(target=check_prod)
    # non_prod_check = threading.Thread(target=check_non_prod)
    # prod_check.start()
    # non_prod_check.start()
    app.run(debug=True)  # Start the Flask application with debug mode enabled
