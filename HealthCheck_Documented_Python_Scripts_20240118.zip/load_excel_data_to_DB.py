from health_check_ping import ping_server
from database import DatabaseConnector
import mysql.connector

class health_check:
    """
    A class to perform health checks on various servers categorized by their environment.
    
    Attributes:
        db (DatabaseConnector): An instance of DatabaseConnector to handle database connections.
        ping (ping_server): An instance of ping_server to perform the actual server pinging.
        server_status (list): A list to store the status of each server after a health check.
    """
    
    def __init__(self) -> None:
        """
        Initializes the health_check class by creating instances of DatabaseConnector and ping_server.
        It also initializes an empty list to store server statuses.
        """
        self.db = DatabaseConnector()  # Database connection setup
        self.ping = ping_server()      # Server pinging setup
        self.server_status = []        # List to store server statuses after health checks
    
    def check_NonProd_servers(self):
        """
        Checks the health of non-production servers by pinging them.
        It distinguishes between servers that require credentials and those that do not.
        """
        no_cred_urls = []  # List to store URLs of servers that do not require credentials
        cred_urls = []     # List to store URLs and credentials of servers that require them
        
        # Establish a connection to the database using the credentials from the DatabaseConnector instance
        conn = mysql.connector.connect(
            host=self.db.host,
            user=self.db.user,
            password=self.db.password,
            database=self.db.database
        )
        
        cursor = conn.cursor()
        
        # Select non-production servers that are enabled and do not require credentials
        cursor.execute("""SELECT * FROM healthcheck.nonprod_healthcheck WHERE isEnable = 1 AND cred = 0""")
        rows = cursor.fetchall()
        for row in rows:
            no_cred_urls.append(row[0])  # Append the server URL to the no_cred_urls list

        # Select non-production servers that are enabled and require credentials
        cursor.execute("""SELECT * FROM healthcheck.nonprod_healthcheck WHERE isEnable = 1 AND cred = 1""")
        rows = cursor.fetchall()
        for row in rows:
            cred_urls.append([row[0], row[1], row[2]])  # Append the server URL and credentials to the cred_urls list
        
        # Ping servers that require credentials and store their status
        for url in cred_urls:
            ping = self.ping.ping_cred_url(url[0], url[1], url[2], "Non_PROD")
            self.server_status.append(ping)

        # Ping servers that do not require credentials and store their status
        for url in no_cred_urls:
            ping = self.ping.ping_Non_cred_url(url, "Non_PROD")
            self.server_status.append(ping)
        
        # Close the database connection if it exists
        if conn:
            conn.close()
    
    # The following methods follow a similar pattern to check_NonProd_servers:
    # - check_Prod_servers: Checks the health of production servers.
    # - check_FOIL_servers: Checks the health of FOIL servers.
    # - check_external_apps_servers: Checks the health of external application servers.
    # Each method establishes a database connection, retrieves the relevant server URLs and credentials,
    # pings the servers, stores their status, and closes the database connection.
    
    def check_Prod_servers(self):
        # Similar to check_NonProd_servers but for production servers
        # ...

    def check_FOIL_servers(self):
        # Similar to check_NonProd_servers but for FOIL servers
        # ...

    def check_external_apps_servers(self):
        # Similar to check_NonProd_servers but for external application servers
        # ...

    def get_servers_status(self):
        """
        Retrieves the status of all servers by performing health checks on each category of servers.
        It resets the server_status list before performing the checks.
        """
        self.server_status = []  # Reset the server status list
        self.check_NonProd_servers()
        self.check_Prod_servers()
        self.check_FOIL_servers()
        self.check_external_apps_servers()

    def get_prod_servers(self):
        """
        Retrieves the status of production, FOIL, and external application servers.
        It resets the server_status list before performing the checks.
        This method is intended to be run periodically, such as every 15 minutes.
        """
        self.server_status = []  # Reset the server status list
        self.check_Prod_servers()
        self.check_FOIL_servers()
        self.check_external_apps_servers()

    def get_non_prod_servers(self):
        """
        Retrieves the status of non-production servers.
        It resets the server_status list before performing the checks.
        """
        self.server_status = []  # Reset the server status list
        self.check_NonProd_servers()
